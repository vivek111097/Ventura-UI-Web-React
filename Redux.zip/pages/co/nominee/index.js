import React from 'react'
import Nominee from '../../../components/clientOnboarding/Nominee/Nominee.component'

const Nominee_Page = () => {
  return (
    <>
    <Nominee/>
    </>
  )
}

export default Nominee_Page