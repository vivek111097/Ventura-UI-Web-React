import React from "react";
import AddSignature from "../../../components/clientOnboarding/WelcomToVentura/AddSignature/AddSignature";
const Nominee_Page = () => {
    return (
      <>
      <AddSignature/>
      </>
    )
  }
  
  export default Nominee_Page