import React from 'react'
import WelcomComponent from '../../../components/clientOnboarding/WelcomToVentura/Welcom.component'
const Welcome = () => {
  return (
    <>
      <WelcomComponent />
    </>
  );
};

export default Welcome;
