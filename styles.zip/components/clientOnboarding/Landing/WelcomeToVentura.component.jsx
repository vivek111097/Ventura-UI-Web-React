import React from 'react'

const WelcomeToVentura = () => {
  return (
    <>
      <h1>welcome to ventura</h1>
      <p>WelcomeToVentura</p>
    </>
  )
}

export default WelcomeToVentura