import React from 'react'

const UploadPan = () => {
  return (
    <div>UploadPan</div>
  )
}

export default UploadPan