import React from 'react'
import AddNominee from '../../../components/clientOnboarding/Nominee/AddNominee.component'


const Nominee_Page = () => {
  return (
    <>
    <AddNominee/>
    </>
  )
}

export default Nominee_Page