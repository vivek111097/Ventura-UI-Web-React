import React from 'react'
import NomineeList from '../../../components/clientOnboarding/Nominee/NomineeList.component'

const nomineelist = () => {
  return (
    <>
    <NomineeList/>
    </>
  )
}

export default nomineelist