import React from 'react'
import axios from 'axios'
const PANCardDetails = () => {

  return (
    <>
<h1> PAN Card Details</h1>
<p>this Component will display the PAN Card data</p>
    </>
  )
}

export default PANCardDetails