import React from 'react'

const WelcomComponent = () => {
  return (
    <>
        <h1>
            this is welcome to ventura components
        </h1>
    </>
  )
}

export default WelcomComponent