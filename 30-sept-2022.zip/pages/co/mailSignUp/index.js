import React from 'react';

const index = () => {
  return (
    <>
      thi is number signup page
    </>
  );
}

export default index;
