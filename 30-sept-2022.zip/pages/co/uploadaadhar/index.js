import React from "react";
import Uploadaadhar from "../../../components/clientOnboarding/Uploadaadhar/Uploadaadhar";
const Upload_Aadhar = () => {
    return (
      <>
        <Uploadaadhar />
      </>
    )
  }
  
  export default Upload_Aadhar