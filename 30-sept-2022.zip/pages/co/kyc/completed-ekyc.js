import React from 'react'
import CompletedEkyc from '../../../components/clientOnboarding/EkycProcess/CompletedEkyc.component'

const completedEkyc = () => {
  return (
<CompletedEkyc/>
  )
}

export default completedEkyc