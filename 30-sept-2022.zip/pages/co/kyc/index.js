import React from 'react'
import CompleteEkyc from '../../../components/clientOnboarding/EkycProcess/CompleteEkyc.component'
import ConfirmDetails from '../../../components/clientOnboarding/EkycProcess/ConfirmDetails.component'

const Kyc = () => {
  return (
    <>
        <CompleteEkyc />
        {/* <ConfirmDetails /> */}
    </>
  )
}

export default Kyc