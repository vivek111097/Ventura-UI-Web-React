import React from 'react'
import IncomeRange from '../../../components/clientOnboarding/PersonalInfo/IncomeRange.component';
const PersonalInfo = () => {
  return (
    <>
      <IncomeRange />
    </>
  );
};

export default PersonalInfo;
