import React from 'react'
import Occupation from '../../../components/clientOnboarding/PersonalInfo/Occupation.component';
const PersonalInfo = () => {
  return (
    <>
      <Occupation />
    </>
  );
};

export default PersonalInfo;
