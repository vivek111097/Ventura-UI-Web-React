import React from 'react'
import TradingExperience from '../../../components/clientOnboarding/PersonalInfo/TradingExperience.component';
const PersonalInfo = () => {
  return (
    <>
      <TradingExperience />
    </>
  );
};

export default PersonalInfo;
