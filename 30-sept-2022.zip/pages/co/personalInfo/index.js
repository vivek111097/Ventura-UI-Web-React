import React from 'react'
import PersonalInfoMain from './../../../components/clientOnboarding/Landing/EKYC/index';
const PersonalInfo = () => {
  return (
    <>
      <PersonalInfoMain />
    </>
  );
};

export default PersonalInfo;
