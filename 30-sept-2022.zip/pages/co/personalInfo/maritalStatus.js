import React from 'react'
import MaritalStatus from '../../../components/clientOnboarding/PersonalInfo/MaritalStatus.component';
const PersonalInfo = () => {
  return (
    <>
      <MaritalStatus />
    </>
  );
};

export default PersonalInfo;
