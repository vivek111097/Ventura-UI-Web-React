import React from 'react';
import PANCardDetailsComponent from '../../../components/clientOnboarding/Landing/VerifyPAN/PANCardDetails.component';

const panDetails = () => {
  return (
    <>
      <PANCardDetailsComponent/>
    </>
  );
}

export default panDetails;
