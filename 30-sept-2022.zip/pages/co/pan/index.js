import React from 'react'
import EnterPan from '../../../components/clientOnboarding/Landing/VerifyPAN/EnterPan.component';

const Nominee_Page = () => {
  return (
    <>
    <EnterPan/>
    </>
  )
}

export default Nominee_Page