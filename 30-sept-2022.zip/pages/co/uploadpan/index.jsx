import React from "react";
import Uploadpan from "../../../components/clientOnboarding/Uploadpan/Uploadpan";
const Upload_Pan = () => {
    return (
      <>
        <Uploadpan />
      </>
    )
  }
  
  export default Upload_Pan