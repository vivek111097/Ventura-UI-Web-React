import React from "react";
import Landing from "../../components/clientOnboarding/Landing/Landing.component";

const LandingCo = () => {
  return (
    <>
      <Landing />
    </>
  );
};

export default LandingCo;
