import React from 'react'
import KraComponent from '../../components/clientOnboarding/Landing/KRA/Kra.component'



const KraDetails = () => {
  return (
    <>
        <KraComponent/>
    </>
  )
}

export default KraDetails