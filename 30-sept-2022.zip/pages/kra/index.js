import React from "react";
import VerifyKra from "../../components/clientOnboarding/Landing/KRA/Verify_Kra.component";

const Kra = () => {
  return (
    <>
      <VerifyKra />
    </>
  );
};

export default Kra;
