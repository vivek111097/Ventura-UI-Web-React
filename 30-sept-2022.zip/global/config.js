export const CO_BaseURL ="https://kyc-stage.ventura1.com/onboarding/v2";
  
