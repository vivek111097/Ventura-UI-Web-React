import React from 'react';
import { useEffect } from 'react';

const FlagSmith = () => {
    useEffect(() => {
        return () => {
            effect
        };
    }, [input])

  return (
    <>
      
    </>
  );
}

export default FlagSmith;
