import React from 'react'
import NomineeListItem from './NomineeListItem.component'

const NomineeList = () => {
  return (
    <NomineeListItem/>
  )
}

export default NomineeList