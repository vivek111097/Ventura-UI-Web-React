import React from 'react';

const AuthContext = React.createContext({
    isClicked:false
});

export default AuthContext;