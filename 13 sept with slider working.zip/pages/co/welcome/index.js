import React from 'react'

const Welcome = () => {
  return (
    <>
    <div>Welcome</div>
    <div>React</div>

      <div className="row justify-content">
        <div className="col-4">
          Its Col-4
        </div>
      </div>
      this is welcome page
    </>
  )
}

export default Welcome